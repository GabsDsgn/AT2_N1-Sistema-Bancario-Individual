package at2.n2;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Client {
    private static final String SERVER_ADDRESS = "10.130.129.103";
    private static final int SERVER_PORT = 12345;
    private static final String MENSAGEM_CODIFICADA = "MTk4Nw=="; 

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();

            System.out.println("Conectaaaado!");

            // Envia a mensagem codificada ao servidor (no caso a máquina do professor)
            byte[] mensagemBytes = MENSAGEM_CODIFICADA.getBytes("UTF-8");
            out.write(mensagemBytes);
            out.flush();

            // Prepara buffer para ler a resposta do servidor
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] data = new byte[1024];
            int bytesRead;

            // Lê a resposta do servidor
            while ((bytesRead = in.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, bytesRead);
                if (bytesRead < data.length) {
                    break;
                }
            }

            // Finalmente, isso converte os bytes em string
            String respostaServidor = new String(buffer.toByteArray(), "UTF-8");
            System.out.println("Resposta do servidor: " + respostaServidor);

            in.close();
            out.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
